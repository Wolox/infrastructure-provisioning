var AWS = require('aws-sdk');
var mandrill = require('mandrill-api/mandrill');

function sendTemplate(to, context) {
  var mandrill_client = new mandrill.Mandrill('Rr89H8w1BMgoByyZuPluHg');
  var template_name = "dinoby";
  var template_content = [];
  var message = {
      "subject": "Welcome to Dinoby!",
      "from_email": "noreply@dinoby.com",
      "from_name": "Dinoby",
      "to": [{
              "email": to,
              "type": "to"
          }]
  };
  var async = true;
  var ip_pool = undefined;
  var send_at = new Date();
  console.log('About to send email to: ' + to)
  mandrill_client.messages.sendTemplate({"template_name": template_name, "template_content": template_content, "message": message, "async": async, "ip_pool": ip_pool, "send_at": send_at}, function(result) {
      console.log(result);
      context.succeed(result)
      /*
      [{
              "email": "recipient.email@example.com",
              "status": "sent",
              "reject_reason": "hard-bounce",
              "_id": "abc123abc123abc123abc123abc123"
          }]
      */
  }, function(e) {
      // Mandrill returns the error as an object with name and message keys
      context.fail("Internal Error: " + JSON.stringify(e));
      console.log('A mandrill error occurred: ' + e.name + ' - ' + e.message);
      // A mandrill error occurred: Unknown_Subaccount - No subaccount exists with the id 'customer-123'
  });
}

exports.handler = function(event, context) {
    var AWS = require('aws-sdk');

    var simpledb = new AWS.SimpleDB({
      endpoint: 'sdb.amazonaws.com',
      region: 'us-east-1'
    });
    console.log(event)
    var params = {
      Attributes: [ /* required */
        {
          Name: 'Email', /* required */
          Value: event.subscriber.email, /* required */
        },
        {
          Name: 'Timestamp', /* required */
          Value: (new Date()).toString(), /* required */
        }
      ],
      DomainName: 'SUBSCRIPTORS', /* required */
      ItemName: event.subscriber.email, /* required */
    };
    simpledb.putAttributes(params, function(err, data) {
      if (err) {
        console.log(err);
        context.fail("Internal Error: " + JSON.stringify(err)); // an error occurred
      }
      else {
        sendTemplate(event.subscriber.email, context)
      }
    });
}
